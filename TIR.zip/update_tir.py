from time import sleep
from urllib.request import urlretrieve
import os
import zipfile
import glob

root_directory = os.getcwd()

tir_zip_files = glob.glob(os.path.join(root_directory, '**', 'TIR'), recursive=True)

if tir_zip_files:
    installation_path = os.path.dirname(tir_zip_files[0])
    
    if installation_path and not installation_path.endswith(os.path.sep):
        installation_path += os.path.sep

    print("Installing TIR")
    
    for i in range(21):
        a = "▶" * i + " " * (20 - i)
        print(f"\r{a} {i * 5}%", end="", flush=True)
        sleep(0.2)

    print()

    url = "https://raw.githubusercontent.com/Only-Up-Offical/tir/main/TIR.zip"

    local_filename, headers = urlretrieve(url, filename=installation_path + "TIR")

    with zipfile.ZipFile(local_filename, 'r') as zip_ref:
        zip_ref.extractall(installation_path)

    print("\nTIR has been successfully installed.")
else:
    print("TIR.zip not found.")
